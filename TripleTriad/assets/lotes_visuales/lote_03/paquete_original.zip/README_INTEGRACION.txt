CARTONES Y MAZMORRAS — LOTE 03, CANDIDATOS DEL PROLOGO

Este paquete incluye CINCO imágenes que ya existen: tres propuestas nuevas de montaje y dos alternativas de ángulo para momentos sobrenaturales. Las imágenes NO han sido integradas y no sustituyen los lotes 01 y 02 aprobados.

Los archivos en cinematicas_hd/ están exportados a 1280x720 RGB PNG; masters_originales/ conserva el PNG original 1672x941.

ORDEN NARRATIVO PROPUESTO
1. escenario_carta_cubierta.png: escenario del torneo, elemento central todavía cubierto.
2. carta_presentada_sin_activar.png: carta exhibida públicamente, previo a manifestación sobrenatural.
3. activacion_carta_plano_cercano.png: energía brotando de la carta; ya no es una presentación normal.
4. (OPCIONAL) publico_reacciona_portal_alternativa.png: reacción de los espectadores durante la crisis.
5. (OPCIONAL) umbral_ruptura_total_alternativa.png: vista extrema de ruptura cósmica, posible alternativa al portal del lote 02.

IMPORTANTE
- El primer lote protege salon_torneo, camino_lluvioso y sala_trono.
- El segundo protege salon_torneo_lleno, revelacion_carta_torneo y portal_umbral_torneo.
- No reemplazar ninguno de ellos automáticamente.
- Evitar agregar escenas, texto o eventos no respaldados por prologo.py. Asociar candidatos sólo con beats ya existentes.
- La carta de estas variantes puede tener diferencias ornamentales; verificar consistencia respecto del Lote 02. Si no coincide, marcar como pendiente y no integrar.
- Para el paso de 1280x800 lógico a 1280x720 fondo: respetar letterbox o viewport HD existente. No deformar, ni cambiar UI, retratos, reglas o música.
- Probar escenas de prologo_pre_duelo, prologo_post_duelo, carta_umbral y transporte; capturas en cada cambio.
- Si el importador necesita otro esquema, adaptar con copia sin tocar ni reescribir manifest.json original.
