# Cartones y Mazmorras — Lote 04: El Umbral y el tránsito

Cuatro fondos candidatos **1280×720, PNG RGB**. Los cuatro masters originales se preservan sin modificaciones en `masters_originales/` y las exportaciones en `cinematicas_hd/`.

## Contenido y posición propuesta

1. `vision_trono_sobre_torneo.png`: visión fugaz del trono desde la sala del torneo, luego de la revelación de El Umbral.
2. `apagon_torneo_anomalia.png`: salón en penumbra con energía residual y fallo de luces; no es un negro absoluto.
3. `ruptura_arena_vortice_alternativa.png`: **alternativa sin aprobación narrativa**, sugiere destrucción física del recinto.
4. `transito_umbral_entre_mundos.png`: **alternativa simbólica**, muestra una transición visual entre realidades que el guion no describe literalmente.

## Reglas de importación

- Proteger los lotes 01, 02 y los recursos ya integrados del lote 03. Nunca sobrescribir nombres existentes ni cambiar mapeos aprobados silenciosamente.
- Validar los hashes SHA-256, PNG y 1280×720 indicados en `manifest.json`.
- Primero colocar las imágenes en área de candidatos/nuevo directorio con nombres únicos; después proponer mapeo a los eventos presentes en código.
- Los dos primeros pueden mapearse si el momento del guion lo respalda. Los dos últimos quedan **pendientes de revisión** (no autoasignar).
- Conservar avatares, cartas, diálogos, música y lógica; probar la pantalla 1280×800 con viewport cinematográfico 1280×720 sin deformación.
- Incluir capturas reales y reporte corto; si hay incompatibilidad narrativa no inventar nuevas escenas sin autorización.

El archivo `docs/PROMPT_OPENCODE.txt` contiene el mensaje para OpenCode.
