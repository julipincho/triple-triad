# Cartones y Mazmorras — Lote 05: llegada al mundo fantástico

**4 fondos nuevos, candidatos, no integrados ni aprobados individualmente.**

- `cinematicas_hd/`: versiones preparadas para el juego, PNG RGB **1280×720**.
- `masters_originales/`: cuatro masters originales **1672×941**, sin modificación.
- `manifest.json`: rol sugerido, advertencias, resolución y SHA-256 de cada imagen.
- `docs/vista_previa_lote05.png`: montaje para revisar las cuatro propuestas.
- `docs/PROMPT_OPENCODE.txt`: instrucciones para importar y comprobar.

## Orden sugerido de revisión

1. `despertar_bosque_ruinas_arcanas.png` — despertar tras el viaje dimensional.
2. `claro_pik_piedra_antigua.png` — primer claro / posible encuentro con Pik.
3. `refugio_nara_campamento.png` — refugio o campamento si el guion lo admite.
4. `mirador_bosque_castillo_lluvia.png` — camino o mirador posterior.

Estos nombres describen **candidatos visuales** y no hechos canónicos. Todos comparten un castillo lejano; evitar usarlos donde contradigan la geografía, la hora o el guion. Un fondo de Nara no presupone que su encuentro ocurra en ese campamento.

## Reglas de integración

- Comprobar integridad de hashes y dimensiones; conservar masters.
- **Nunca sobrescribir** arte o mappings aprobados (Lotes 01–04). Importar a staging separado.
- Mantener la historia, retratos, avatares, cartas, música y mecánicas intactas.
- Revisar `prologo.py`, `cinematicas.py`, `finales.py` y claves compartidas antes de seleccionar fondos.
- Cuidado con claves genéricas como `camino` / `campamento` reutilizadas en escenas distintas.
- Validar visualmente el viewport cinematográfico 1280×720 dentro del tamaño lógico 1280×800.
- Entregar capturas y lista explícita de integrados vs. candidatos pendientes; sin merge automático.
